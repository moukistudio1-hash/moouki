const state = {
  token: localStorage.getItem('lbal_token') || '',
  user: null,
  items: [],
  lastDetailItem: null
};

const els = {
  authButton: document.getElementById('authButton'),
  sellButton: document.getElementById('sellButton'),
  searchForm: document.getElementById('searchForm'),
  searchInput: document.getElementById('searchInput'),
  categoryFilter: document.getElementById('categoryFilter'),
  conditionFilter: document.getElementById('conditionFilter'),
  minPriceFilter: document.getElementById('minPriceFilter'),
  maxPriceFilter: document.getElementById('maxPriceFilter'),
  sortFilter: document.getElementById('sortFilter'),
  resetFilters: document.getElementById('resetFilters'),
  itemsGrid: document.getElementById('itemsGrid'),
  itemCount: document.getElementById('itemCount'),
  toast: document.getElementById('toast'),
  authModal: document.getElementById('authModal'),
  authForm: document.getElementById('authForm'),
  authMode: document.getElementById('authMode'),
  authTitle: document.getElementById('authTitle'),
  authName: document.getElementById('authName'),
  authEmail: document.getElementById('authEmail'),
  authPassword: document.getElementById('authPassword'),
  authCity: document.getElementById('authCity'),
  switchAuthMode: document.getElementById('switchAuthMode'),
  sellModal: document.getElementById('sellModal'),
  sellForm: document.getElementById('sellForm'),
  itemModal: document.getElementById('itemModal'),
  itemDetails: document.getElementById('itemDetails'),
  dashboardModal: document.getElementById('dashboardModal'),
  dashboardContent: document.getElementById('dashboardContent'),
  openFavorites: document.getElementById('openFavorites'),
  openDashboard: document.getElementById('openDashboard')
};

const money = new Intl.NumberFormat('en-MA', { style: 'currency', currency: 'MAD', maximumFractionDigits: 0 });

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function showToast(message, type = 'success') {
  els.toast.textContent = message;
  els.toast.className = `toast show ${type === 'error' ? 'error' : ''}`;
  window.setTimeout(() => { els.toast.className = 'toast'; }, 3000);
}

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;

  const response = await fetch(path, { ...options, headers });
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || 'Something went wrong.');
  }
  return data;
}

function requireAuth() {
  if (state.user) return true;
  openAuthModal('login');
  showToast('Please login first.', 'error');
  return false;
}

function setSession({ token, user }) {
  state.token = token;
  state.user = user;
  localStorage.setItem('lbal_token', token);
  updateHeader();
}

function clearSession() {
  state.token = '';
  state.user = null;
  localStorage.removeItem('lbal_token');
  updateHeader();
  loadItems();
}

function updateHeader() {
  els.authButton.textContent = state.user ? 'Logout' : 'Login';
  els.sellButton.textContent = state.user ? 'Sell now' : 'Login to sell';
}

function openAuthModal(mode = 'login') {
  els.authMode.value = mode;
  const isRegister = mode === 'register';
  els.authTitle.textContent = isRegister ? 'Create account' : 'Login';
  els.switchAuthMode.textContent = isRegister ? 'I already have an account' : 'Create a new account';
  document.querySelectorAll('.register-only').forEach((el) => el.classList.toggle('hidden', !isRegister));
  els.authModal.showModal();
}

function itemCard(item) {
  const fallback = 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&w=900&q=80';
  const heart = Number(item.is_favorited) ? '♥' : '♡';
  return `
    <article class="item-card">
      <div class="item-image-wrap">
        <img src="${escapeHtml(item.image_url || fallback)}" alt="${escapeHtml(item.title)}" loading="lazy" />
        <button class="favorite-btn ${Number(item.is_favorited) ? 'active' : ''}" type="button" data-favorite-id="${item.id}" aria-label="Favorite ${escapeHtml(item.title)}">${heart}</button>
      </div>
      <div class="item-body">
        <h3 class="item-title">${escapeHtml(item.title)}</h3>
        <p class="item-meta">${escapeHtml(item.brand || 'No brand')} · ${escapeHtml(item.size || 'One size')} · ${escapeHtml(item.item_condition)}</p>
        <div class="item-price"><span>${money.format(item.price)}</span><small>${Number(item.favorite_count || 0)} fav</small></div>
        <button class="item-open" type="button" data-item-id="${item.id}">View details</button>
      </div>
    </article>
  `;
}

function renderItems(items = state.items) {
  els.itemCount.textContent = `${items.length} item${items.length === 1 ? '' : 's'}`;
  if (!items.length) {
    els.itemsGrid.innerHTML = '<div class="empty-state"><h3>No items found</h3><p>Try a different search or publish the first item in this category.</p></div>';
    return;
  }
  els.itemsGrid.innerHTML = items.map(itemCard).join('');
}

function currentFilters() {
  const params = new URLSearchParams();
  const search = els.searchInput.value.trim();
  if (search) params.set('search', search);
  if (els.categoryFilter.value) params.set('category', els.categoryFilter.value);
  if (els.conditionFilter.value) params.set('condition', els.conditionFilter.value);
  if (els.minPriceFilter.value) params.set('min_price', els.minPriceFilter.value);
  if (els.maxPriceFilter.value) params.set('max_price', els.maxPriceFilter.value);
  if (els.sortFilter.value) params.set('sort', els.sortFilter.value);
  return params.toString();
}

async function loadItems() {
  els.itemsGrid.innerHTML = '<div class="empty-state"><h3>Loading items...</h3></div>';
  try {
    const query = currentFilters();
    const data = await api(`/api/items${query ? `?${query}` : ''}`);
    state.items = data.items;
    renderItems();
  } catch (error) {
    showToast(error.message, 'error');
    els.itemsGrid.innerHTML = '<div class="empty-state"><h3>Could not load items</h3></div>';
  }
}

async function loadMe() {
  if (!state.token) return updateHeader();
  try {
    const data = await api('/api/me');
    state.user = data.user;
  } catch (_error) {
    clearSession();
  }
  updateHeader();
}

async function openItemDetails(id) {
  try {
    const { item } = await api(`/api/items/${id}`);
    state.lastDetailItem = item;
    const canBuy = state.user && item.seller_id !== state.user.id && item.status === 'available';
    const canMessage = state.user && item.seller_id !== state.user.id;
    els.itemDetails.innerHTML = `
      <div class="item-detail-grid">
        <div class="item-detail-image">
          <img src="${escapeHtml(item.image_url)}" alt="${escapeHtml(item.title)}" />
        </div>
        <div class="item-detail-info">
          <p class="eyebrow">${escapeHtml(item.category)}</p>
          <h2>${escapeHtml(item.title)}</h2>
          <p class="price-big">${money.format(item.price)}</p>
          <p>${escapeHtml(item.description)}</p>
          <div class="pills">
            <span class="pill">${escapeHtml(item.item_condition)}</span>
            <span class="pill">Size: ${escapeHtml(item.size || 'One size')}</span>
            <span class="pill">Brand: ${escapeHtml(item.brand || 'No brand')}</span>
            <span class="pill">Color: ${escapeHtml(item.color || '-')}</span>
            <span class="pill">${Number(item.views)} views</span>
          </div>
          <div class="seller-box">
            <strong>${escapeHtml(item.seller_name)}</strong>
            <p class="muted">Seller from ${escapeHtml(item.seller_city || 'Morocco')} · Status: ${escapeHtml(item.status)}</p>
          </div>
          <div class="detail-actions">
            <button class="secondary-btn" type="button" data-favorite-id="${item.id}">${Number(item.is_favorited) ? 'Remove favorite' : 'Add favorite'}</button>
            <button class="primary-btn" type="button" data-buy-id="${item.id}" ${canBuy ? '' : 'disabled'}>${canBuy ? 'Reserve item' : 'Unavailable'}</button>
          </div>
          <div class="message-box">
            <textarea id="messageBody" placeholder="Ask the seller a question..." ${canMessage ? '' : 'disabled'}></textarea>
            <button class="ghost-btn" type="button" data-message-id="${item.id}" ${canMessage ? '' : 'disabled'}>Send message</button>
          </div>
        </div>
      </div>
    `;
    els.itemModal.showModal();
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function toggleFavorite(id) {
  if (!requireAuth()) return;
  try {
    const data = await api(`/api/items/${id}/favorite`, { method: 'POST' });
    showToast(data.favorited ? 'Saved to favorites.' : 'Removed from favorites.');
    await loadItems();
    if (state.lastDetailItem && Number(state.lastDetailItem.id) === Number(id) && els.itemModal.open) {
      await openItemDetails(id);
    }
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function reserveItem(id) {
  if (!requireAuth()) return;
  try {
    await api(`/api/items/${id}/orders`, { method: 'POST' });
    showToast('Item reserved. Add real payment/shipping before production.');
    els.itemModal.close();
    await loadItems();
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function sendMessage(id) {
  if (!requireAuth()) return;
  const body = document.getElementById('messageBody')?.value.trim();
  if (!body) return showToast('Write a message first.', 'error');
  try {
    await api(`/api/items/${id}/messages`, {
      method: 'POST',
      body: JSON.stringify({ body })
    });
    document.getElementById('messageBody').value = '';
    showToast('Message sent to seller.');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function openDashboard(type = 'dashboard') {
  if (!requireAuth()) return;
  els.dashboardContent.innerHTML = '<div class="dashboard-card"><p>Loading...</p></div>';
  els.dashboardModal.showModal();
  try {
    if (type === 'favorites') {
      const { items } = await api('/api/me/favorites');
      els.dashboardContent.innerHTML = `
        <div class="dashboard-card">
          <h3>Favorite items</h3>
          ${items.length ? `<ul class="simple-list">${items.map((item) => `
            <li><img src="${escapeHtml(item.image_url)}" alt=""><span><strong>${escapeHtml(item.title)}</strong><br><small>${money.format(item.price)} · ${escapeHtml(item.seller_name)}</small></span><button class="ghost-btn" data-item-id="${item.id}">Open</button></li>
          `).join('')}</ul>` : '<p class="muted">No favorites yet.</p>'}
        </div>
      `;
      return;
    }

    const [{ buying, sales }, { messages }] = await Promise.all([
      api('/api/me/orders'),
      api('/api/me/messages')
    ]);

    els.dashboardContent.innerHTML = `
      <div class="dashboard-card">
        <h3>Profile</h3>
        <p><strong>${escapeHtml(state.user.name)}</strong><br><span class="muted">${escapeHtml(state.user.email)} · ${escapeHtml(state.user.city || '')}</span></p>
      </div>
      <div class="dashboard-card">
        <h3>Buying orders</h3>
        ${buying.length ? `<ul class="simple-list">${buying.map(order => `
          <li><img src="${escapeHtml(order.image_url)}" alt=""><span><strong>${escapeHtml(order.title)}</strong><br><small>${money.format(order.total_price)} · ${escapeHtml(order.status)} · Seller: ${escapeHtml(order.seller_name)}</small></span><span></span></li>
        `).join('')}</ul>` : '<p class="muted">No buying orders yet.</p>'}
      </div>
      <div class="dashboard-card">
        <h3>Sales</h3>
        ${sales.length ? `<ul class="simple-list">${sales.map(order => `
          <li><img src="${escapeHtml(order.image_url)}" alt=""><span><strong>${escapeHtml(order.title)}</strong><br><small>${money.format(order.total_price)} · ${escapeHtml(order.status)} · Buyer: ${escapeHtml(order.buyer_name)}</small></span><span></span></li>
        `).join('')}</ul>` : '<p class="muted">No sales yet.</p>'}
      </div>
      <div class="dashboard-card">
        <h3>Messages</h3>
        ${messages.length ? `<ul class="simple-list">${messages.map(message => `
          <li><img src="${escapeHtml(message.image_url)}" alt=""><span><strong>${escapeHtml(message.item_title)}</strong><br><small>${escapeHtml(message.sender_name)} → ${escapeHtml(message.receiver_name)}</small><br>${escapeHtml(message.body)}</span><span></span></li>
        `).join('')}</ul>` : '<p class="muted">No messages yet.</p>'}
      </div>
    `;
  } catch (error) {
    showToast(error.message, 'error');
  }
}

els.authButton.addEventListener('click', () => {
  if (state.user) {
    clearSession();
    showToast('Logged out.');
  } else {
    openAuthModal('login');
  }
});

els.sellButton.addEventListener('click', () => {
  if (!requireAuth()) return;
  els.sellModal.showModal();
});

document.querySelectorAll('[data-open-sell]').forEach((btn) => btn.addEventListener('click', () => {
  if (!requireAuth()) return;
  els.sellModal.showModal();
}));

document.querySelectorAll('[data-scroll-items]').forEach((btn) => btn.addEventListener('click', () => {
  document.getElementById('itemsSection').scrollIntoView({ behavior: 'smooth' });
}));

document.querySelectorAll('[data-close-modal]').forEach((btn) => btn.addEventListener('click', () => {
  document.getElementById(btn.dataset.closeModal).close();
}));

els.switchAuthMode.addEventListener('click', () => {
  openAuthModal(els.authMode.value === 'login' ? 'register' : 'login');
});

els.authForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const mode = els.authMode.value;
  const payload = {
    email: els.authEmail.value.trim(),
    password: els.authPassword.value
  };
  if (mode === 'register') {
    payload.name = els.authName.value.trim();
    payload.city = els.authCity.value.trim() || 'Casablanca';
  }

  try {
    const data = await api(`/api/auth/${mode}`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    setSession(data);
    els.authForm.reset();
    els.authModal.close();
    showToast(mode === 'register' ? 'Account created.' : 'Welcome back.');
    await loadItems();
  } catch (error) {
    showToast(error.message, 'error');
  }
});

els.sellForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!requireAuth()) return;

  const payload = {
    title: document.getElementById('sellTitle').value.trim(),
    price: Number(document.getElementById('sellPrice').value),
    category: document.getElementById('sellCategory').value,
    item_condition: document.getElementById('sellCondition').value,
    size: document.getElementById('sellSize').value.trim(),
    brand: document.getElementById('sellBrand').value.trim(),
    color: document.getElementById('sellColor').value.trim(),
    image_url: document.getElementById('sellImage').value.trim(),
    description: document.getElementById('sellDescription').value.trim()
  };

  try {
    await api('/api/items', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    els.sellForm.reset();
    els.sellModal.close();
    showToast('Item published.');
    await loadItems();
  } catch (error) {
    showToast(error.message, 'error');
  }
});

els.searchForm.addEventListener('submit', (event) => {
  event.preventDefault();
  loadItems();
});

[els.categoryFilter, els.conditionFilter, els.sortFilter].forEach((el) => el.addEventListener('change', loadItems));
[els.minPriceFilter, els.maxPriceFilter].forEach((el) => el.addEventListener('input', () => {
  window.clearTimeout(window.priceFilterTimer);
  window.priceFilterTimer = window.setTimeout(loadItems, 450);
}));

els.resetFilters.addEventListener('click', () => {
  els.searchInput.value = '';
  els.categoryFilter.value = '';
  els.conditionFilter.value = '';
  els.minPriceFilter.value = '';
  els.maxPriceFilter.value = '';
  els.sortFilter.value = 'newest';
  loadItems();
});

els.itemsGrid.addEventListener('click', (event) => {
  const favorite = event.target.closest('[data-favorite-id]');
  const item = event.target.closest('[data-item-id]');
  if (favorite) toggleFavorite(favorite.dataset.favoriteId);
  if (item) openItemDetails(item.dataset.itemId);
});

els.itemDetails.addEventListener('click', (event) => {
  const favorite = event.target.closest('[data-favorite-id]');
  const buy = event.target.closest('[data-buy-id]');
  const message = event.target.closest('[data-message-id]');
  if (favorite) toggleFavorite(favorite.dataset.favoriteId);
  if (buy) reserveItem(buy.dataset.buyId);
  if (message) sendMessage(message.dataset.messageId);
});

els.openFavorites.addEventListener('click', () => openDashboard('favorites'));
els.openDashboard.addEventListener('click', () => openDashboard('dashboard'));

(async function init() {
  await loadMe();
  await loadItems();
})();
