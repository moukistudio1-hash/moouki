# Lbal Ou Vintage

A full-stack MVP for a second-hand and vintage marketplace inspired by modern resale platforms, built with an original UI and brand identity.

> Important: This is not a Vinted clone with copied assets, copy, trademarks, or proprietary design. It is an original marketplace starter using similar marketplace concepts: listings, search, favorites, seller contact, and orders.

## Features

- Responsive marketplace frontend
- User registration and login with JWT
- Password hashing with bcrypt
- SQLite database with automatic seed data
- Item listing creation
- Search by title, description, and brand
- Category, condition, price, and sort filters
- Item detail modal
- Favorites / wishlist
- Buyer order reservation flow
- Buyer-seller messages
- Account dashboard with favorites, orders, sales, and messages
- REST API backend

## Tech stack

- Frontend: HTML, CSS, vanilla JavaScript
- Backend: Node.js, Express
- Database: SQLite via better-sqlite3
- Auth: JWT + bcryptjs

## Project structure

```txt
lbal-ou-vintage/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── server.js
├── package.json
├── .env.example
├── .gitignore
└── README.md
```

## Run locally

```bash
cd lbal-ou-vintage
cp .env.example .env
npm install
npm run dev
```

Open:

```txt
http://localhost:3000
```

Demo account:

```txt
Email: seller@lbal.test
Password: demo1234
```

## API overview

### Auth

```txt
POST /api/auth/register
POST /api/auth/login
GET  /api/me
```

### Items

```txt
GET   /api/items
GET   /api/items/:id
POST  /api/items
PATCH /api/items/:id
POST  /api/items/:id/favorite
GET   /api/me/favorites
```

### Orders

```txt
POST /api/items/:id/orders
GET  /api/me/orders
```

### Messages

```txt
POST /api/items/:id/messages
GET  /api/me/messages
```

## Example register request

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"demo1234","city":"Casablanca"}'
```

## Example create item request

```bash
curl -X POST http://localhost:3000/api/items \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "title":"Vintage bomber jacket",
    "description":"Clean condition, oversized fit.",
    "price":300,
    "category":"Jackets",
    "size":"L",
    "item_condition":"Very good",
    "brand":"No brand",
    "color":"Black",
    "image_url":"https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=900&q=80"
  }'
```

## What to add before real launch

1. Real image upload with Cloudinary, S3, or local storage + moderation.
2. Payment integration such as Stripe, CMI, PayPal, or local Moroccan payment provider.
3. Shipping price rules, pickup/drop-off workflow, and tracking numbers.
4. Email verification and password reset.
5. Seller ratings and buyer protection logic.
6. Admin dashboard for reports, banned products, refunds, and disputes.
7. Strong rate limiting, audit logs, CSRF strategy if cookie auth is used, and production security hardening.
8. Terms, privacy policy, prohibited item rules, and support pages.

## Environment variables

```txt
PORT=3000
JWT_SECRET=change-this-secret-before-production
DATABASE_FILE=./lbal_ou_vintage.sqlite
```

## Deploy notes

For a simple first deployment:

- Use Render, Railway, Fly.io, or a VPS with Node.js.
- Keep `JWT_SECRET` private.
- Use a persistent volume for SQLite or move to PostgreSQL/MySQL for production.
- Put the app behind HTTPS.
