require('dotenv').config();

const express = require('express');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret-change-me';
const DATABASE_FILE = process.env.DATABASE_FILE || './lbal_ou_vintage.sqlite';
const db = new Database(DATABASE_FILE);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(morgan('dev'));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      avatar TEXT,
      city TEXT DEFAULT 'Casablanca',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      seller_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      price REAL NOT NULL CHECK(price >= 0),
      category TEXT NOT NULL,
      size TEXT DEFAULT '',
      item_condition TEXT NOT NULL,
      brand TEXT DEFAULT '',
      color TEXT DEFAULT '',
      image_url TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available', 'reserved', 'sold')),
      views INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS favorites (
      user_id INTEGER NOT NULL,
      item_id INTEGER NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, item_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      buyer_id INTEGER NOT NULL,
      item_id INTEGER NOT NULL UNIQUE,
      total_price REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'paid', 'shipped', 'completed', 'cancelled')),
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL,
      receiver_id INTEGER NOT NULL,
      item_id INTEGER NOT NULL,
      body TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
    );
  `);
}

function seedDb() {
  const count = db.prepare('SELECT COUNT(*) AS count FROM users').get().count;
  if (count > 0) return;

  const hash = bcrypt.hashSync('demo1234', 10);
  const users = [
    ['Anouar Vintage', 'seller@lbal.test', hash, 'Casablanca'],
    ['Sara Closet', 'sara@lbal.test', hash, 'Rabat'],
    ['Youssef Thrift', 'youssef@lbal.test', hash, 'Marrakech']
  ];

  const insertUser = db.prepare('INSERT INTO users (name, email, password_hash, city) VALUES (?, ?, ?, ?)');
  const userIds = users.map((user) => insertUser.run(...user).lastInsertRowid);

  const items = [
    [userIds[0], 'Vintage leather jacket', 'Original brown leather jacket, clean condition, perfect for winter.', 420, 'Jackets', 'M', 'Very good', 'Zara', 'Brown', 'https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=900&q=80'],
    [userIds[1], 'Nike retro sweatshirt', 'Soft oversized sweatshirt. Small mark inside, invisible when worn.', 180, 'Sweatshirts', 'L', 'Good', 'Nike', 'Grey', 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=80'],
    [userIds[2], 'Classic denim jeans', 'Blue straight jeans, vintage fit, strong fabric.', 150, 'Jeans', '32', 'Very good', 'Levi\'s', 'Blue', 'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=900&q=80'],
    [userIds[0], 'Adidas campus sneakers', 'Used but clean. Sole still strong. Comes without box.', 260, 'Shoes', '42', 'Good', 'Adidas', 'Black', 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80'],
    [userIds[1], 'Women vintage blazer', 'Elegant beige blazer, made in Italy style.', 230, 'Blazers', 'S', 'Like new', 'Mango', 'Beige', 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=900&q=80'],
    [userIds[2], 'Old school cap', 'Simple streetwear cap, adjustable size.', 70, 'Accessories', 'One size', 'Good', 'New Era', 'Green', 'https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=900&q=80'],
    [userIds[0], 'Minimal black dress', 'Clean black dress, perfect for evening looks.', 190, 'Dresses', 'M', 'Very good', 'H&M', 'Black', 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=900&q=80'],
    [userIds[1], 'Vintage crossbody bag', 'Small brown bag with old-money vintage look.', 210, 'Bags', 'One size', 'Good', 'No brand', 'Brown', 'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&w=900&q=80']
  ];

  const insertItem = db.prepare(`
    INSERT INTO items (seller_id, title, description, price, category, size, item_condition, brand, color, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  items.forEach((item) => insertItem.run(...item));
}

initDb();
seedDb();

function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
}

function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    avatar: user.avatar,
    city: user.city,
    created_at: user.created_at
  };
}

function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Login required.' });

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.id);
    if (!user) return res.status(401).json({ error: 'Invalid session.' });
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid or expired session.' });
  }
}

function optionalAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next();
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.id) || null;
  } catch (_error) {
    req.user = null;
  }
  next();
}

function cleanString(value, max = 255) {
  return String(value || '').trim().slice(0, max);
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, name: 'Lbal Ou Vintage API' });
});

app.post('/api/auth/register', (req, res) => {
  const name = cleanString(req.body.name, 80);
  const email = cleanString(req.body.email, 120).toLowerCase();
  const password = String(req.body.password || '');
  const city = cleanString(req.body.city || 'Casablanca', 80);

  if (!name || !email || password.length < 8) {
    return res.status(400).json({ error: 'Name, valid email, and password with 8+ characters are required.' });
  }

  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (exists) return res.status(409).json({ error: 'This email is already registered.' });

  const passwordHash = bcrypt.hashSync(password, 10);
  const result = db.prepare('INSERT INTO users (name, email, password_hash, city) VALUES (?, ?, ?, ?)').run(name, email, passwordHash, city);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);

  res.status(201).json({ user: publicUser(user), token: signToken(user) });
});

app.post('/api/auth/login', (req, res) => {
  const email = cleanString(req.body.email, 120).toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Wrong email or password.' });
  }

  res.json({ user: publicUser(user), token: signToken(user) });
});

app.get('/api/me', authRequired, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

app.get('/api/items', optionalAuth, (req, res) => {
  const search = cleanString(req.query.search || '', 120);
  const category = cleanString(req.query.category || '', 80);
  const condition = cleanString(req.query.condition || '', 80);
  const minPrice = Number(req.query.min_price || 0);
  const maxPrice = Number(req.query.max_price || 0);
  const sort = cleanString(req.query.sort || 'newest', 30);

  const where = ['i.status = ?'];
  const params = ['available'];

  if (search) {
    where.push('(LOWER(i.title) LIKE ? OR LOWER(i.description) LIKE ? OR LOWER(i.brand) LIKE ?)');
    const term = `%${search.toLowerCase()}%`;
    params.push(term, term, term);
  }
  if (category) {
    where.push('i.category = ?');
    params.push(category);
  }
  if (condition) {
    where.push('i.item_condition = ?');
    params.push(condition);
  }
  if (Number.isFinite(minPrice) && minPrice > 0) {
    where.push('i.price >= ?');
    params.push(minPrice);
  }
  if (Number.isFinite(maxPrice) && maxPrice > 0) {
    where.push('i.price <= ?');
    params.push(maxPrice);
  }

  const sortSql = {
    newest: 'i.created_at DESC',
    cheapest: 'i.price ASC',
    expensive: 'i.price DESC',
    popular: 'i.views DESC, i.created_at DESC'
  }[sort] || 'i.created_at DESC';

  const userId = req.user?.id || 0;
  const sql = `
    SELECT
      i.*,
      u.name AS seller_name,
      u.city AS seller_city,
      COUNT(f2.user_id) AS favorite_count,
      CASE WHEN f.user_id IS NULL THEN 0 ELSE 1 END AS is_favorited
    FROM items i
    JOIN users u ON u.id = i.seller_id
    LEFT JOIN favorites f ON f.item_id = i.id AND f.user_id = ?
    LEFT JOIN favorites f2 ON f2.item_id = i.id
    WHERE ${where.join(' AND ')}
    GROUP BY i.id
    ORDER BY ${sortSql}
    LIMIT 80
  `;

  res.json({ items: db.prepare(sql).all(userId, ...params) });
});

app.get('/api/items/:id', optionalAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Invalid item id.' });

  db.prepare('UPDATE items SET views = views + 1 WHERE id = ?').run(id);
  const userId = req.user?.id || 0;
  const item = db.prepare(`
    SELECT
      i.*,
      u.name AS seller_name,
      u.city AS seller_city,
      u.avatar AS seller_avatar,
      COUNT(f2.user_id) AS favorite_count,
      CASE WHEN f.user_id IS NULL THEN 0 ELSE 1 END AS is_favorited
    FROM items i
    JOIN users u ON u.id = i.seller_id
    LEFT JOIN favorites f ON f.item_id = i.id AND f.user_id = ?
    LEFT JOIN favorites f2 ON f2.item_id = i.id
    WHERE i.id = ?
    GROUP BY i.id
  `).get(userId, id);

  if (!item) return res.status(404).json({ error: 'Item not found.' });
  res.json({ item });
});

app.post('/api/items', authRequired, (req, res) => {
  const title = cleanString(req.body.title, 100);
  const description = cleanString(req.body.description, 1000);
  const price = Number(req.body.price);
  const category = cleanString(req.body.category, 80);
  const size = cleanString(req.body.size, 50);
  const itemCondition = cleanString(req.body.item_condition, 80);
  const brand = cleanString(req.body.brand, 80);
  const color = cleanString(req.body.color, 60);
  const imageUrl = cleanString(req.body.image_url || 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&w=900&q=80', 600);

  if (!title || !description || !category || !itemCondition || !Number.isFinite(price) || price <= 0) {
    return res.status(400).json({ error: 'Title, description, category, condition, and positive price are required.' });
  }

  const result = db.prepare(`
    INSERT INTO items (seller_id, title, description, price, category, size, item_condition, brand, color, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(req.user.id, title, description, price, category, size, itemCondition, brand, color, imageUrl);

  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ item });
});

app.patch('/api/items/:id', authRequired, (req, res) => {
  const id = Number(req.params.id);
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(id);
  if (!item) return res.status(404).json({ error: 'Item not found.' });
  if (item.seller_id !== req.user.id) return res.status(403).json({ error: 'You can only edit your own items.' });

  const fields = {
    title: cleanString(req.body.title ?? item.title, 100),
    description: cleanString(req.body.description ?? item.description, 1000),
    price: Number(req.body.price ?? item.price),
    category: cleanString(req.body.category ?? item.category, 80),
    size: cleanString(req.body.size ?? item.size, 50),
    item_condition: cleanString(req.body.item_condition ?? item.item_condition, 80),
    brand: cleanString(req.body.brand ?? item.brand, 80),
    color: cleanString(req.body.color ?? item.color, 60),
    image_url: cleanString(req.body.image_url ?? item.image_url, 600),
    status: cleanString(req.body.status ?? item.status, 20)
  };

  if (!['available', 'reserved', 'sold'].includes(fields.status)) return res.status(400).json({ error: 'Invalid status.' });

  db.prepare(`
    UPDATE items SET title = ?, description = ?, price = ?, category = ?, size = ?, item_condition = ?, brand = ?, color = ?, image_url = ?, status = ?
    WHERE id = ?
  `).run(fields.title, fields.description, fields.price, fields.category, fields.size, fields.item_condition, fields.brand, fields.color, fields.image_url, fields.status, id);

  res.json({ item: db.prepare('SELECT * FROM items WHERE id = ?').get(id) });
});

app.post('/api/items/:id/favorite', authRequired, (req, res) => {
  const itemId = Number(req.params.id);
  const item = db.prepare('SELECT id FROM items WHERE id = ?').get(itemId);
  if (!item) return res.status(404).json({ error: 'Item not found.' });

  const existing = db.prepare('SELECT 1 FROM favorites WHERE user_id = ? AND item_id = ?').get(req.user.id, itemId);
  if (existing) {
    db.prepare('DELETE FROM favorites WHERE user_id = ? AND item_id = ?').run(req.user.id, itemId);
    return res.json({ favorited: false });
  }
  db.prepare('INSERT INTO favorites (user_id, item_id) VALUES (?, ?)').run(req.user.id, itemId);
  res.status(201).json({ favorited: true });
});

app.get('/api/me/favorites', authRequired, (req, res) => {
  const items = db.prepare(`
    SELECT i.*, u.name AS seller_name, u.city AS seller_city, 1 AS is_favorited
    FROM favorites f
    JOIN items i ON i.id = f.item_id
    JOIN users u ON u.id = i.seller_id
    WHERE f.user_id = ?
    ORDER BY f.created_at DESC
  `).all(req.user.id);
  res.json({ items });
});

app.post('/api/items/:id/orders', authRequired, (req, res) => {
  const itemId = Number(req.params.id);
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(itemId);
  if (!item) return res.status(404).json({ error: 'Item not found.' });
  if (item.status !== 'available') return res.status(409).json({ error: 'This item is not available.' });
  if (item.seller_id === req.user.id) return res.status(400).json({ error: 'You cannot buy your own item.' });

  const tx = db.transaction(() => {
    const order = db.prepare('INSERT INTO orders (buyer_id, item_id, total_price, status) VALUES (?, ?, ?, ?)')
      .run(req.user.id, item.id, item.price, 'pending');
    db.prepare('UPDATE items SET status = ? WHERE id = ?').run('reserved', item.id);
    return order.lastInsertRowid;
  });

  const orderId = tx();
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  res.status(201).json({ order, message: 'Order created. Connect a real payment gateway before production.' });
});

app.get('/api/me/orders', authRequired, (req, res) => {
  const buying = db.prepare(`
    SELECT o.*, i.title, i.image_url, i.seller_id, u.name AS seller_name
    FROM orders o
    JOIN items i ON i.id = o.item_id
    JOIN users u ON u.id = i.seller_id
    WHERE o.buyer_id = ?
    ORDER BY o.created_at DESC
  `).all(req.user.id);

  const sales = db.prepare(`
    SELECT o.*, i.title, i.image_url, buyer.name AS buyer_name
    FROM orders o
    JOIN items i ON i.id = o.item_id
    JOIN users buyer ON buyer.id = o.buyer_id
    WHERE i.seller_id = ?
    ORDER BY o.created_at DESC
  `).all(req.user.id);

  res.json({ buying, sales });
});

app.post('/api/items/:id/messages', authRequired, (req, res) => {
  const itemId = Number(req.params.id);
  const body = cleanString(req.body.body, 1000);
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(itemId);
  if (!item) return res.status(404).json({ error: 'Item not found.' });
  if (!body) return res.status(400).json({ error: 'Message body is required.' });

  const receiverId = item.seller_id === req.user.id ? Number(req.body.receiver_id || 0) : item.seller_id;
  if (!receiverId || receiverId === req.user.id) return res.status(400).json({ error: 'Invalid receiver.' });

  const result = db.prepare('INSERT INTO messages (sender_id, receiver_id, item_id, body) VALUES (?, ?, ?, ?)')
    .run(req.user.id, receiverId, itemId, body);

  res.status(201).json({ message: db.prepare('SELECT * FROM messages WHERE id = ?').get(result.lastInsertRowid) });
});

app.get('/api/me/messages', authRequired, (req, res) => {
  const messages = db.prepare(`
    SELECT m.*, i.title AS item_title, i.image_url, sender.name AS sender_name, receiver.name AS receiver_name
    FROM messages m
    JOIN items i ON i.id = m.item_id
    JOIN users sender ON sender.id = m.sender_id
    JOIN users receiver ON receiver.id = m.receiver_id
    WHERE m.sender_id = ? OR m.receiver_id = ?
    ORDER BY m.created_at DESC
  `).all(req.user.id, req.user.id);
  res.json({ messages });
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Lbal Ou Vintage running on http://localhost:${PORT}`);
  console.log('Demo login: seller@lbal.test / demo1234');
});
